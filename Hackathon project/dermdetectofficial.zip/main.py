
# Run in console! Use pip3 if necessary. Make sure python is installed.
#pip install tensorflow
#pip install numpy
#pip install cv
#pip install opencv-python
#pip install tk
#pip install shutil
#pip install pillow



import tensorflow as tf
import numpy as np
import cv2
from tensorflow.keras.applications import  VGG19


# make sure connected to internet
vgg_model = VGG19(weights = 'imagenet',  include_top = False, input_shape = (180, 180, 3))

def predict_skin_disease(image_path):
    class_names = ["Acne","Eczema","Atopic","Psoriasis","Tinea","vitiligo"]

    # Load saved model
    model = tf.keras.models.load_model('/content/drive/My Drive/kaggle-skin/6claass.h5')

    # Load and preprocess image
    img = cv2.imread(image_path)
    img = cv2.resize(img, (180, 180))
    img = np.array(img) / 255.0
    img = np.expand_dims(img, axis=0)
    img = vgg_model.predict(img)
    img = img.reshape(1, -1)

    # Make prediction on preprocessed image

    pred = model.predict(img)[0]

    pred[0]=pred[0]*3 # improve acne accuracy
    print(class_names)
    print(pred)

    predicted_class_index = np.argmax(pred)
    predicted_class_second = np.argsort(pred)[-2]

    predicted_class_name = class_names[predicted_class_index]
    predicted_second_class_name = class_names[predicted_class_second]

    return predicted_class_name, predicted_second_class_name

#print(predict_skin_disease("/content/drive/My Drive/kaggle-skin/skindatasets/test/Normal/0_0_aidai_0029.jpg")) #("/kaggle/input/skindat
#"/kaggle/input/skindatasets/skin/test/Normal/0_0_aidai_0029.jpg"


# exampler on how to run
print(predict_skin_disease("image/eczema-example.jpg"))
print()

print(predict_skin_disease("image/atopic.jpg"))
print()


